Vendored @gpuix/native 0.6.2 (Wave 3.2 spring integrator).

Darwin-arm64: run scripts/rebuild-gpuix-native-mac.sh so
gpuix-native.darwin-arm64.node sits next to index.js. Do not install
npm @gpuix/native-darwin-arm64@0.6.0 — that binary has no spring.

Linux/Windows optional deps stay on 0.6.0 for bun test / CI only.
